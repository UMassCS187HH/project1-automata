An honors project for CS187HH, Data Structures. See the BitArray2D.pdf file for more info
