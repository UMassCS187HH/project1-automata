package automata.conwaysgameoflife.support;

public class Main
{

	public static void main(String[] args)
	{
		new SetupFrame();
	}

}
