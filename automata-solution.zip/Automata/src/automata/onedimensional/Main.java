package automata.onedimensional;
public class Main
{
	public static void main(String[] args) throws InterruptedException
	{
		new SetupFrame();
	}
}
