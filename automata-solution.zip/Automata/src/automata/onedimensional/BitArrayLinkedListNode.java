package automata.onedimensional;
public class BitArrayLinkedListNode
{
	public BitArray val;
	public BitArrayLinkedListNode nextNode;
}